#include "EJ/GL/application/EJGL_Window.hpp"
#include "EJ/GL/camera/EJGL_Camera.hpp"

EJGL_NAMESPACE_BEGIN

EJGLWindow::EJGLWindow(int width_, int height_, const char* name_,
	const glfw::Monitor* monitor_,
	const glfw::Window* share_) :
	::glfw::Window{ width_, height_, name_, monitor_, share_ },
	_lastSize{ width_, height_ }
{
	posEvent.addEvent("onPosEvent", onPosEvent);
	sizeEvent.addEvent("onSizeEvent", onSizeEvent);
	closeEvent.addEvent("onCloseEvent", onCloseEvent);
	refreshEvent.addEvent("onRefreshEvent", onRefreshEvent);
	focusEvent.addEvent("onFocusEvent", onFocusEvent);
	iconifyEvent.addEvent("onIconifyEvent", onIconifyEvent);
	maximizeEvent.addEvent("onMaximizeEvent", onMaximizeEvent);
	framebufferSizeEvent.addEvent("onFramebufferSizeEvent", onFramebufferSizeEvent);
	contentScaleEvent.addEvent("onContentScaleEvent", onContentScaleEvent);
	keyEvent.addEvent("onKeyEvent", onKeyEvent);
	charEvent.addEvent("onCharEvent", onCharEvent);
	mouseButtonEvent.addEvent("onMouseEvent", onMouseEvent);
	cursorPosEvent.addEvent("onCursorPosEvent", onCursorPosEvent);
	cursorEnterEvent.addEvent("onCursorEnterEvent", onCursorEnterEvent);
	scrollEvent.addEvent("onScrollEvent", onScrollEvent);
	dropEvent.addEvent("onDropEvent", onDropEvent);
}

std::string EJGLWindow::toString() const noexcept {
	return std::string("[Window]{ width: ") + std::to_string(getWidth()) +
		", height: " + std::to_string(getHeight()) + " }";
}

EJGLWindow::~EJGLWindow() {
	_deleteCamera();
	posEvent.removeEvent("onPosEvent");
	sizeEvent.removeEvent("onSizeEvent");
	closeEvent.removeEvent("onCloseEvent");
	refreshEvent.removeEvent("onRefreshEvent");
	focusEvent.removeEvent("onFocusEvent");
	iconifyEvent.removeEvent("onIconifyEvent");
	maximizeEvent.removeEvent("onMaximizeEvent");
	framebufferSizeEvent.removeEvent("onFramebufferSizeEvent");
	contentScaleEvent.removeEvent("onContentScaleEvent");
	keyEvent.removeEvent("onKeyEvent");
	charEvent.removeEvent("onCharEvent");
	mouseButtonEvent.removeEvent("onMouseEvent");
	cursorPosEvent.removeEvent("onCursorPosEvent");
	cursorEnterEvent.removeEvent("onCursorEnterEvent");
	scrollEvent.removeEvent("onScrollEvent");
	dropEvent.removeEvent("onDropEvent");
}

void EJGLWindow::_deleteCamera() {
	delete _camera;
}

EJGLWindow& EJGLWindow::GetWrapperFromHandle(Window& handle_) {
	return static_cast<EJGLWindow&>(handle_);
}
EJGLWindow& EJGLWindow::GetWrapperFromHandle(GLFWwindow* handle_) {
	return static_cast<EJGLWindow&>(::glfw::Window::getWrapperFromHandle(handle_));
}

::glfw::FunctionReturnType EJGLWindow::onPosEvent(Window& window_, int, int) {
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onSizeEvent(Window& window_, int width_, int height_) {
	EJGLWindow& w = EJGLWindow::GetWrapperFromHandle(window_);
	if (w.isCameraValid()) {
		if (w._camera->getWindowSizeCB())
			w._camera->getWindowSizeCB()(w, width_, height_);
	}
	w._lastSize = glm::ivec2(width_, height_);
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onCloseEvent(Window&) {
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onRefreshEvent(Window&) {
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onFocusEvent(Window& window_, bool) {
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onIconifyEvent(Window& window_, bool) {
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onMaximizeEvent(Window& window_, bool) {
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onFramebufferSizeEvent(Window& window_, int width_, int height_) {
	glViewport(0, 0, width_, height_);
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onContentScaleEvent(Window& window_, float, float) {
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onKeyEvent(Window& window_, KeyCode keyCode_, int scancode_, KeyState action_, ModifierKeyBit mods_) {
	EJGLWindow& w = EJGLWindow::GetWrapperFromHandle(window_);
	if (w.isCameraValid()) {
		if (w._camera->getKeyCB())
			w._camera->getKeyCB()(w, keyCode_, scancode_, action_, mods_);
	}
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onCharEvent(Window& window_, unsigned int) {
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onMouseEvent(Window& window_, MouseButton button_, MouseButtonState action_, ModifierKeyBit mods_) {
	EJGLWindow& w = EJGLWindow::GetWrapperFromHandle(window_);
	if (w.isCameraValid()) {
		if (w._camera->getMouseButtonCB())
			w._camera->getMouseButtonCB()(w, button_, action_, mods_);
	}
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onCursorPosEvent(Window& window_, double x_, double y_) {
	EJGLWindow& w = EJGLWindow::GetWrapperFromHandle(window_);
	if (w.isCameraValid()) {
		if (w._camera->getMouseMoveCB())
			w._camera->getMouseMoveCB()(w, x_, y_);
	}
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onCursorEnterEvent(Window& window_, bool) {
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onScrollEvent(Window& window_, double x_, double y_) {
	EJGLWindow& w = EJGLWindow::GetWrapperFromHandle(window_);
	if (w.isCameraValid()) {
		if (w._camera->getScrollCB())
			w._camera->getScrollCB()(w, x_, y_);
	}
	return ::glfw::FunctionReturnType::Keep;
}
::glfw::FunctionReturnType EJGLWindow::onDropEvent(Window& window_, std::vector<const char*>) {
	return ::glfw::FunctionReturnType::Keep;
}

EJGL_NAMESPACE_END