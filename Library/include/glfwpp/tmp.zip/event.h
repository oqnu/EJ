#ifndef GLFWPP_EVENT_H
#define GLFWPP_EVENT_H

#include <GLFW/glfw3.h>
#include <functional>
#include <map>

namespace glfw
{
    enum class FunctionReturnType : int {
        Keep,
        Stop,
    };
    template<typename... Args>
    class Event
    {
    public:
        using FunctionReturnType = ::glfw::FunctionReturnType;
        using FunctionType = std::function<FunctionReturnType(Args...)>;
        using FunctionsType = std::map<std::string, FunctionType>;

    private:
        FunctionsType _functions{};

    public:
        inline const FunctionsType& functions() const {
            return _functions;
        }
        inline FunctionsType& functions() {
            return _functions;
        }

        inline bool addEvent(const std::string& name_, const FunctionType& function_) {
            return _functions.emplace(name_, function_).second;
        }
        inline void removeEvent(const std::string& name_) {
            _functions.erase(name_);
        }
        
        void operator()(Args... args_) const
        {
            for (const auto& val : _functions)
            {
                FunctionReturnType ret = val.second(args_...);
                if (ret == FunctionReturnType::Stop) {
                    return;
                }
            }
        }
    };

    inline void pollEvents()
    {
        glfwPollEvents();
    }

    inline void waitEvents()
    {
        glfwWaitEvents();
    }
    inline void waitEvents(double timeout_)
    {
        glfwWaitEventsTimeout(timeout_);
    }

    inline void postEmptyEvent()
    {
        glfwPostEmptyEvent();
    }
}  // namespace glfw

#endif  //GLFWPP_EVENT_H
